# Paradise Nursery

A simple React-based Paradise Nursery project starter.

## Project files

- `src/AboutUs.jsx` – About Us page component.
- `src/App.css` – Styles for the nursery landing page and About Us section.

## Getting started

This folder contains the three files requested for the Coursera submission. Add them to the matching locations in your existing React project if your course provides one.

If you are creating a React project from scratch, create a React app first and place `AboutUs.jsx` and `App.css` inside its `src` folder.

## Note

This is a starter implementation. Update the content and styling to match the exact requirements and screenshots in your Coursera course before submitting.
